# PlacePrep — Smart Placement Preparation Tracker

A full-stack Java web application to track your placement preparation journey.  
Built with **Java Servlets + JDBC + MySQL + HTML/CSS/JS**.

---

## Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Backend    | Java 11, Servlets (javax.servlet 4) |
| Database   | MySQL 8 + JDBC (mysql-connector-j)  |
| JSON       | Google Gson 2.10                    |
| Frontend   | HTML5, CSS3, Vanilla JS (Fetch API) |
| Build      | Maven 3.x                           |
| Server     | Apache Tomcat 9 / 10                |

---

## Project Structure

```
PlacementTracker/
├── pom.xml
├── sql/
│   └── schema.sql                          ← DB schema + seed data
└── src/main/
    ├── java/com/placementtracker/
    │   ├── model/
    │   │   ├── Topic.java
    │   │   ├── Problem.java
    │   │   └── MockTest.java
    │   ├── dao/
    │   │   ├── TopicDAO.java               ← Full CRUD + analytics
    │   │   ├── ProblemDAO.java             ← CRUD + filters + analytics
    │   │   └── MockTestDAO.java            ← CRUD + score stats
    │   ├── servlet/
    │   │   ├── DashboardServlet.java       ← GET /dashboard
    │   │   ├── TopicServlet.java           ← /topics
    │   │   ├── ProblemServlet.java         ← /problems
    │   │   └── MockTestServlet.java        ← /mocktests
    │   └── util/
    │       ├── DBConnection.java
    │       └── EncodingFilter.java
    └── webapp/
        ├── index.html                      ← Single-page UI
        ├── css/style.css
        ├── js/app.js                       ← All API calls & UI logic
        └── WEB-INF/web.xml
```

---

## Setup Instructions

### 1. Prerequisites

- Java JDK 11+
- Maven 3.6+
- MySQL 8.0+
- Apache Tomcat 9 or 10
- IDE: IntelliJ IDEA / Eclipse (optional)

---

### 2. Database Setup

Open MySQL Workbench or your terminal and run:

```bash
mysql -u root -p < sql/schema.sql
```

Or paste the contents of `sql/schema.sql` into MySQL Workbench and execute.

This will:
- Create the `placement_tracker` database
- Create tables: `users`, `topics`, `problems`, `mock_tests`
- Insert a demo user and sample seed data

---

### 3. Configure DB Connection

Edit `src/main/java/com/placementtracker/util/DBConnection.java`:

```java
private static final String DB_URL  = "jdbc:mysql://localhost:3306/placement_tracker"
                                     + "?useSSL=false&serverTimezone=UTC";
private static final String USER     = "root";       // ← your MySQL username
private static final String PASSWORD = "yourpass";   // ← your MySQL password
```

---

### 4. Build the WAR

```bash
cd PlacementTracker
mvn clean package
```

The WAR file is generated at:
```
target/PlacementTracker.war
```

---

### 5. Deploy to Tomcat

**Option A — Copy WAR manually:**
```bash
cp target/PlacementTracker.war $TOMCAT_HOME/webapps/
```
Start Tomcat and navigate to:
```
http://localhost:8080/PlacementTracker/
```

**Option B — Maven Tomcat plugin:**
```bash
mvn tomcat7:run
```
Then open:
```
http://localhost:8080/PlacementTracker/
```

---

## REST API Reference

### Dashboard
| Method | URL         | Description              |
|--------|-------------|--------------------------|
| GET    | /dashboard  | Aggregated stats for UI  |

### Topics
| Method | URL              | Description       |
|--------|------------------|-------------------|
| GET    | /topics          | List all topics   |
| GET    | /topics?id={n}   | Get single topic  |
| POST   | /topics          | Create topic      |
| PUT    | /topics?id={n}   | Update topic      |
| DELETE | /topics?id={n}   | Delete topic      |

**POST/PUT params:** `name`, `category`, `status`, `priority`, `progress` (0–100), `notes`

### Problems
| Method | URL                                      | Description              |
|--------|------------------------------------------|--------------------------|
| GET    | /problems                                | List all                 |
| GET    | /problems?difficulty=Easy&status=Solved  | Filtered list            |
| GET    | /problems?id={n}                         | Get single               |
| POST   | /problems                                | Log new problem          |
| PUT    | /problems?id={n}                         | Update problem           |
| DELETE | /problems?id={n}                         | Delete problem           |

**POST/PUT params:** `name`, `topic`, `difficulty`, `status`, `timeTaken`, `notes`, `solvedDate`

### Mock Tests
| Method | URL               | Description      |
|--------|-------------------|------------------|
| GET    | /mocktests        | List all         |
| GET    | /mocktests?id={n} | Get single       |
| POST   | /mocktests        | Record new test  |
| PUT    | /mocktests?id={n} | Update test      |
| DELETE | /mocktests?id={n} | Delete test      |

**POST/PUT params:** `name`, `testDate`, `score`, `timeTaken`, `weakAreas`, `remarks`

---

## Features

- **Dashboard** — Metrics, topic progress bars, activity heatmap, recent problems
- **Topics** — Full CRUD with category, status, progress %, priority, notes
- **Problems** — Log problems with difficulty, status (Solved/Attempted/Revisit), time, notes; filter by difficulty/status
- **Mock Tests** — Record test name, date, score, time, weak areas, remarks
- **Progress Analytics** — Problems by difficulty bar chart, mock score trend, weak-area topic cards
- **OOP Design** — Model / DAO / Servlet three-layer architecture
- **SQL CRUD** — All operations use PreparedStatements (SQL injection safe)
- **UTF-8 Filter** — EncodingFilter ensures consistent encoding

---

## Database Schema

```sql
users       (id, name, email, branch, grad_year, created_at)
topics      (id, user_id, name, category, status, priority, progress, notes, ...)
problems    (id, user_id, name, topic, difficulty, status, time_taken, notes, solved_date, ...)
mock_tests  (id, user_id, name, test_date, score, time_taken, weak_areas, remarks, ...)
```

All tables use `ON DELETE CASCADE` foreign keys from `users`.

---

## Extending the Project

| Feature idea              | Where to add                          |
|---------------------------|---------------------------------------|
| User login/register       | New `UserServlet` + `LoginServlet`     |
| Company-wise question sets| New `CompanyProblem` model + DAO       |
| Email reminders           | `javax.mail` + scheduler servlet       |
| Export to PDF/CSV         | Apache POI / OpenCSV in a new servlet  |
| REST JSON body (not form) | Swap `getParameter` for Gson body parse|

---

## License

MIT — free to use, modify, and submit as your project.
