package com.placementtracker.servlet;

import com.google.gson.Gson;
import com.placementtracker.dao.ProblemDAO;
import com.placementtracker.model.Problem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST-style servlet for problem CRUD.
 * GET    /problems?difficulty=&status=   → list (with optional filters)
 * POST   /problems                       → add problem
 * PUT    /problems?id=                   → update problem
 * DELETE /problems?id=                   → delete problem
 */
@WebServlet("/problems")
public class ProblemServlet extends HttpServlet {

    private final ProblemDAO problemDAO = new ProblemDAO();
    private final Gson       gson       = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        try {
            String idParam = req.getParameter("id");
            if (idParam != null) {
                Problem p = problemDAO.getProblemById(Integer.parseInt(idParam));
                res.getWriter().print(p != null ? gson.toJson(p) : "{}");
            } else {
                String diff   = req.getParameter("difficulty");
                String status = req.getParameter("status");
                List<Problem> list = (diff != null || status != null)
                    ? problemDAO.getProblemsFiltered(userId, diff, status)
                    : problemDAO.getProblemsByUser(userId);
                res.getWriter().print(gson.toJson(list));
            }
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);

        String name       = req.getParameter("name");
        String topic      = req.getParameter("topic");
        String difficulty = req.getParameter("difficulty");
        String status     = req.getParameter("status");
        int    timeTaken  = parseInt(req.getParameter("timeTaken"), 0);
        String notes      = req.getParameter("notes");
        String dateStr    = req.getParameter("solvedDate");

        if (name == null || name.trim().isEmpty()) {
            sendError(res, 400, "Problem name is required"); return;
        }

        Date solvedDate;
        try { solvedDate = (dateStr != null && !dateStr.isEmpty()) ? Date.valueOf(dateStr)
                                                                    : new Date(System.currentTimeMillis()); }
        catch (IllegalArgumentException e) { solvedDate = new Date(System.currentTimeMillis()); }

        Problem p = new Problem(userId, name.trim(), topic, difficulty, status, timeTaken, notes, solvedDate);
        try {
            boolean ok = problemDAO.addProblem(p);
            sendResult(res, ok, "Problem logged", "Failed to log problem");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);
        if (id == 0) { sendError(res, 400, "Missing problem id"); return; }

        try {
            Problem p = problemDAO.getProblemById(id);
            if (p == null || p.getUserId() != userId) { sendError(res, 404, "Not found"); return; }
            if (req.getParameter("name")       != null) p.setName      (req.getParameter("name"));
            if (req.getParameter("topic")      != null) p.setTopic     (req.getParameter("topic"));
            if (req.getParameter("difficulty") != null) p.setDifficulty(req.getParameter("difficulty"));
            if (req.getParameter("status")     != null) p.setStatus    (req.getParameter("status"));
            if (req.getParameter("timeTaken")  != null) p.setTimeTaken (parseInt(req.getParameter("timeTaken"), p.getTimeTaken()));
            if (req.getParameter("notes")      != null) p.setNotes     (req.getParameter("notes"));
            boolean ok = problemDAO.updateProblem(p);
            sendResult(res, ok, "Problem updated", "Update failed");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);
        if (id == 0) { sendError(res, 400, "Missing problem id"); return; }
        try {
            boolean ok = problemDAO.deleteProblem(id, userId);
            sendResult(res, ok, "Problem deleted", "Problem not found");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    private int getSessionUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return (s != null && s.getAttribute("userId") != null) ? (int) s.getAttribute("userId") : 1;
    }
    private void sendResult(HttpServletResponse res, boolean ok, String s, String f) throws IOException {
        Map<String,Object> m = new HashMap<>(); m.put("success",ok); m.put("message",ok?s:f);
        res.setStatus(ok?200:400); res.getWriter().print(gson.toJson(m));
    }
    private void sendError(HttpServletResponse res, int code, String msg) throws IOException {
        res.setStatus(code); Map<String,Object> m = new HashMap<>();
        m.put("success",false); m.put("message",msg); res.getWriter().print(gson.toJson(m));
    }
    private int parseInt(String s, int d) {
        try { return (s!=null&&!s.isEmpty())?Integer.parseInt(s):d; } catch(NumberFormatException e){return d;}
    }
}
