package com.placementtracker.servlet;

import com.google.gson.Gson;
import com.placementtracker.dao.MockTestDAO;
import com.placementtracker.model.MockTest;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST-style servlet for mock test CRUD.
 */
@WebServlet("/mocktests")
public class MockTestServlet extends HttpServlet {

    private final MockTestDAO mockTestDAO = new MockTestDAO();
    private final Gson        gson        = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        try {
            String idParam = req.getParameter("id");
            if (idParam != null) {
                MockTest m = mockTestDAO.getMockTestById(Integer.parseInt(idParam));
                res.getWriter().print(m != null ? gson.toJson(m) : "{}");
            } else {
                List<MockTest> list = mockTestDAO.getMockTestsByUser(userId);
                res.getWriter().print(gson.toJson(list));
            }
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);

        String name      = req.getParameter("name");
        String dateStr   = req.getParameter("testDate");
        int    score     = parseInt(req.getParameter("score"), 0);
        int    timeTaken = parseInt(req.getParameter("timeTaken"), 0);
        String weakAreas = req.getParameter("weakAreas");
        String remarks   = req.getParameter("remarks");

        if (name == null || name.trim().isEmpty()) {
            sendError(res, 400, "Test name is required"); return;
        }

        Date testDate;
        try { testDate = (dateStr != null && !dateStr.isEmpty()) ? Date.valueOf(dateStr)
                                                                  : new Date(System.currentTimeMillis()); }
        catch (IllegalArgumentException e) { testDate = new Date(System.currentTimeMillis()); }

        MockTest m = new MockTest(userId, name.trim(), testDate, score, timeTaken, weakAreas, remarks);
        try {
            boolean ok = mockTestDAO.addMockTest(m);
            sendResult(res, ok, "Mock test recorded", "Failed to record test");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);
        if (id == 0) { sendError(res, 400, "Missing test id"); return; }

        try {
            MockTest m = mockTestDAO.getMockTestById(id);
            if (m == null || m.getUserId() != userId) { sendError(res, 404, "Not found"); return; }
            if (req.getParameter("name")      != null) m.setName     (req.getParameter("name"));
            if (req.getParameter("score")     != null) m.setScore    (parseInt(req.getParameter("score"),m.getScore()));
            if (req.getParameter("timeTaken") != null) m.setTimeTaken(parseInt(req.getParameter("timeTaken"),m.getTimeTaken()));
            if (req.getParameter("weakAreas") != null) m.setWeakAreas(req.getParameter("weakAreas"));
            if (req.getParameter("remarks")   != null) m.setRemarks  (req.getParameter("remarks"));
            boolean ok = mockTestDAO.updateMockTest(m);
            sendResult(res, ok, "Test updated", "Update failed");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);
        if (id == 0) { sendError(res, 400, "Missing test id"); return; }
        try {
            boolean ok = mockTestDAO.deleteMockTest(id, userId);
            sendResult(res, ok, "Test deleted", "Test not found");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    private int getSessionUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return (s != null && s.getAttribute("userId") != null) ? (int) s.getAttribute("userId") : 1;
    }
    private void sendResult(HttpServletResponse res, boolean ok, String s, String f) throws IOException {
        Map<String,Object> m = new HashMap<>(); m.put("success",ok); m.put("message",ok?s:f);
        res.setStatus(ok?200:400); res.getWriter().print(gson.toJson(m));
    }
    private void sendError(HttpServletResponse res, int code, String msg) throws IOException {
        res.setStatus(code); Map<String,Object> m = new HashMap<>();
        m.put("success",false); m.put("message",msg); res.getWriter().print(gson.toJson(m));
    }
    private int parseInt(String s, int d) {
        try { return (s!=null&&!s.isEmpty())?Integer.parseInt(s):d; } catch(NumberFormatException e){return d;}
    }
}
