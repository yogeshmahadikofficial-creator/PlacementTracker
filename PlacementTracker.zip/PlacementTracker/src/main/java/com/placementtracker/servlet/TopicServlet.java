package com.placementtracker.servlet;

import com.google.gson.Gson;
import com.placementtracker.dao.TopicDAO;
import com.placementtracker.model.Topic;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST-style servlet for topic CRUD.
 * Endpoints:
 *   GET    /topics          → list all topics for session user
 *   POST   /topics          → create a new topic (JSON body)
 *   PUT    /topics?id={n}   → update topic
 *   DELETE /topics?id={n}   → delete topic
 */
@WebServlet("/topics")
public class TopicServlet extends HttpServlet {

    private final TopicDAO topicDAO = new TopicDAO();
    private final Gson     gson     = new Gson();

    // ── GET ──────────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        PrintWriter out = res.getWriter();
        int userId = getSessionUserId(req);

        try {
            String idParam = req.getParameter("id");
            if (idParam != null) {
                Topic t = topicDAO.getTopicById(Integer.parseInt(idParam));
                out.print(t != null ? gson.toJson(t) : "{}");
            } else {
                List<Topic> topics = topicDAO.getTopicsByUser(userId);
                out.print(gson.toJson(topics));
            }
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    // ── POST ─────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);

        String name     = req.getParameter("name");
        String category = req.getParameter("category");
        String status   = req.getParameter("status");
        String priority = req.getParameter("priority");
        int    progress = parseInt(req.getParameter("progress"), 0);
        String notes    = req.getParameter("notes");

        if (name == null || name.trim().isEmpty()) {
            sendError(res, 400, "Topic name is required");
            return;
        }

        Topic t = new Topic(userId, name.trim(), category, status, priority, progress, notes);
        try {
            boolean ok = topicDAO.addTopic(t);
            sendResult(res, ok, "Topic added successfully", "Failed to add topic");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    // ── PUT ──────────────────────────────────────────────────
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);

        if (id == 0) { sendError(res, 400, "Missing topic id"); return; }

        try {
            Topic t = topicDAO.getTopicById(id);
            if (t == null || t.getUserId() != userId) {
                sendError(res, 404, "Topic not found"); return;
            }
            if (req.getParameter("name")     != null) t.setName    (req.getParameter("name"));
            if (req.getParameter("category") != null) t.setCategory(req.getParameter("category"));
            if (req.getParameter("status")   != null) t.setStatus  (req.getParameter("status"));
            if (req.getParameter("priority") != null) t.setPriority(req.getParameter("priority"));
            if (req.getParameter("progress") != null) t.setProgress(parseInt(req.getParameter("progress"), t.getProgress()));
            if (req.getParameter("notes")    != null) t.setNotes   (req.getParameter("notes"));

            boolean ok = topicDAO.updateTopic(t);
            sendResult(res, ok, "Topic updated", "Update failed");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    // ── DELETE ───────────────────────────────────────────────
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);
        int id     = parseInt(req.getParameter("id"), 0);

        if (id == 0) { sendError(res, 400, "Missing topic id"); return; }
        try {
            boolean ok = topicDAO.deleteTopic(id, userId);
            sendResult(res, ok, "Topic deleted", "Topic not found");
        } catch (SQLException e) {
            sendError(res, 500, e.getMessage());
        }
    }

    // ── Helpers ───────────────────────────────────────────────
    private int getSessionUserId(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("userId") != null)
            return (int) session.getAttribute("userId");
        return 1;   // default to demo user when session management not set up
    }

    private void sendResult(HttpServletResponse res, boolean ok,
                            String successMsg, String failMsg) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("success", ok);
        map.put("message", ok ? successMsg : failMsg);
        res.setStatus(ok ? 200 : 400);
        res.getWriter().print(gson.toJson(map));
    }

    private void sendError(HttpServletResponse res, int code, String msg) throws IOException {
        res.setStatus(code);
        Map<String, Object> map = new HashMap<>();
        map.put("success", false);
        map.put("message", msg);
        res.getWriter().print(gson.toJson(map));
    }

    private int parseInt(String s, int def) {
        try { return (s != null && !s.isEmpty()) ? Integer.parseInt(s) : def; }
        catch (NumberFormatException e) { return def; }
    }
}
