package com.placementtracker.servlet;

import com.google.gson.Gson;
import com.placementtracker.dao.MockTestDAO;
import com.placementtracker.dao.ProblemDAO;
import com.placementtracker.dao.TopicDAO;
import com.placementtracker.model.Problem;
import com.placementtracker.model.Topic;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Provides aggregated stats for the dashboard page.
 * GET /dashboard → JSON with topics, problemStats, mockStats, recentProblems
 */
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private final TopicDAO    topicDAO    = new TopicDAO();
    private final ProblemDAO  problemDAO  = new ProblemDAO();
    private final MockTestDAO mockTestDAO = new MockTestDAO();
    private final Gson        gson        = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("application/json;charset=UTF-8");
        int userId = getSessionUserId(req);

        try {
            Map<String, Object> data = new HashMap<>();

            // ── Topic stats ──────────────────────────────────
            List<Topic> topics      = topicDAO.getTopicsByUser(userId);
            int totalTopics         = topics.size();
            int completedTopics     = (int) topics.stream()
                                                  .filter(t -> "Completed".equals(t.getStatus()))
                                                  .count();
            Map<String, Object> topicStats = new HashMap<>();
            topicStats.put("total",     totalTopics);
            topicStats.put("completed", completedTopics);
            topicStats.put("list",      topics);
            topicStats.put("weak",      topicDAO.getWeakTopics(userId, 50));
            data.put("topicStats", topicStats);

            // ── Problem stats ────────────────────────────────
            Map<String, Object> problemStats = new HashMap<>();
            problemStats.put("solved",    problemDAO.countSolved(userId));
            problemStats.put("easy",      problemDAO.countByDifficulty(userId, "Easy"));
            problemStats.put("medium",    problemDAO.countByDifficulty(userId, "Medium"));
            problemStats.put("hard",      problemDAO.countByDifficulty(userId, "Hard"));
            data.put("problemStats", problemStats);

            // ── Recent problems ──────────────────────────────
            List<Problem> recent = problemDAO.getRecent(userId, 5);
            data.put("recentProblems", recent);

            // ── Mock test stats ──────────────────────────────
            Map<String, Object> mockStats = new HashMap<>();
            mockStats.put("total",    mockTestDAO.getMockTestsByUser(userId).size());
            mockStats.put("avgScore", Math.round(mockTestDAO.getAverageScore(userId)));
            mockStats.put("best",     mockTestDAO.getBestScore(userId));
            data.put("mockStats", mockStats);

            res.getWriter().print(gson.toJson(data));

        } catch (SQLException e) {
            res.setStatus(500);
            Map<String, Object> err = new HashMap<>();
            err.put("error", e.getMessage());
            res.getWriter().print(gson.toJson(err));
        }
    }

    private int getSessionUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return (s != null && s.getAttribute("userId") != null) ? (int) s.getAttribute("userId") : 1;
    }
}
