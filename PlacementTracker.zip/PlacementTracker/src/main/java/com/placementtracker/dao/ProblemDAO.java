package com.placementtracker.dao;

import com.placementtracker.model.Problem;
import com.placementtracker.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for the problems table.
 */
public class ProblemDAO {

    // ── Create ────────────────────────────────────────────────
    public boolean addProblem(Problem p) throws SQLException {
        String sql = "INSERT INTO problems (user_id, name, topic, difficulty, status, time_taken, notes, solved_date) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt   (1, p.getUserId());
            ps.setString(2, p.getName());
            ps.setString(3, p.getTopic());
            ps.setString(4, p.getDifficulty());
            ps.setString(5, p.getStatus());
            ps.setInt   (6, p.getTimeTaken());
            ps.setString(7, p.getNotes());
            ps.setDate  (8, p.getSolvedDate() != null ? p.getSolvedDate()
                                                       : new Date(System.currentTimeMillis()));
            return ps.executeUpdate() > 0;
        }
    }

    // ── Read all ─────────────────────────────────────────────
    public List<Problem> getProblemsByUser(int userId) throws SQLException {
        String sql = "SELECT * FROM problems WHERE user_id=? ORDER BY created_at DESC";
        return fetchList(sql, userId);
    }

    // ── Read with filters ────────────────────────────────────
    public List<Problem> getProblemsFiltered(int userId, String difficulty, String status)
            throws SQLException {
        StringBuilder sb = new StringBuilder(
            "SELECT * FROM problems WHERE user_id=?");
        if (difficulty != null && !difficulty.isEmpty()) sb.append(" AND difficulty=?");
        if (status     != null && !status.isEmpty())     sb.append(" AND status=?");
        sb.append(" ORDER BY created_at DESC");

        List<Problem> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sb.toString())) {
            int idx = 1;
            ps.setInt(idx++, userId);
            if (difficulty != null && !difficulty.isEmpty()) ps.setString(idx++, difficulty);
            if (status     != null && !status.isEmpty())     ps.setString(idx++, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Read single ──────────────────────────────────────────
    public Problem getProblemById(int id) throws SQLException {
        String sql = "SELECT * FROM problems WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Update ────────────────────────────────────────────────
    public boolean updateProblem(Problem p) throws SQLException {
        String sql = "UPDATE problems SET name=?, topic=?, difficulty=?, status=?, "
                   + "time_taken=?, notes=?, solved_date=? WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setString(2, p.getTopic());
            ps.setString(3, p.getDifficulty());
            ps.setString(4, p.getStatus());
            ps.setInt   (5, p.getTimeTaken());
            ps.setString(6, p.getNotes());
            ps.setDate  (7, p.getSolvedDate());
            ps.setInt   (8, p.getId());
            ps.setInt   (9, p.getUserId());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ────────────────────────────────────────────────
    public boolean deleteProblem(int id, int userId) throws SQLException {
        String sql = "DELETE FROM problems WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Analytics: count by difficulty ───────────────────────
    public int countByDifficulty(int userId, String difficulty) throws SQLException {
        String sql = "SELECT COUNT(*) FROM problems WHERE user_id=? AND difficulty=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId); ps.setString(2, difficulty);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    // ── Analytics: total solved ───────────────────────────────
    public int countSolved(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM problems WHERE user_id=? AND status='Solved'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    // ── Recent N problems ────────────────────────────────────
    public List<Problem> getRecent(int userId, int limit) throws SQLException {
        String sql = "SELECT * FROM problems WHERE user_id=? ORDER BY created_at DESC LIMIT ?";
        List<Problem> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId); ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Internal helper ──────────────────────────────────────
    private List<Problem> fetchList(String sql, int userId) throws SQLException {
        List<Problem> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Mapper ───────────────────────────────────────────────
    private Problem map(ResultSet rs) throws SQLException {
        Problem p = new Problem();
        p.setId        (rs.getInt   ("id"));
        p.setUserId    (rs.getInt   ("user_id"));
        p.setName      (rs.getString("name"));
        p.setTopic     (rs.getString("topic"));
        p.setDifficulty(rs.getString("difficulty"));
        p.setStatus    (rs.getString("status"));
        p.setTimeTaken (rs.getInt   ("time_taken"));
        p.setNotes     (rs.getString("notes"));
        p.setSolvedDate(rs.getDate  ("solved_date"));
        p.setCreatedAt (rs.getTimestamp("created_at"));
        return p;
    }
}
