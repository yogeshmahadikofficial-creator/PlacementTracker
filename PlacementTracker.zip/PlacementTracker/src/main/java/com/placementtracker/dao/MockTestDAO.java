package com.placementtracker.dao;

import com.placementtracker.model.MockTest;
import com.placementtracker.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for the mock_tests table.
 */
public class MockTestDAO {

    // ── Create ────────────────────────────────────────────────
    public boolean addMockTest(MockTest m) throws SQLException {
        String sql = "INSERT INTO mock_tests (user_id, name, test_date, score, time_taken, weak_areas, remarks) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt   (1, m.getUserId());
            ps.setString(2, m.getName());
            ps.setDate  (3, m.getTestDate());
            ps.setInt   (4, m.getScore());
            ps.setInt   (5, m.getTimeTaken());
            ps.setString(6, m.getWeakAreas());
            ps.setString(7, m.getRemarks());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Read all ─────────────────────────────────────────────
    public List<MockTest> getMockTestsByUser(int userId) throws SQLException {
        String sql = "SELECT * FROM mock_tests WHERE user_id=? ORDER BY test_date DESC";
        List<MockTest> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Read single ──────────────────────────────────────────
    public MockTest getMockTestById(int id) throws SQLException {
        String sql = "SELECT * FROM mock_tests WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Update ────────────────────────────────────────────────
    public boolean updateMockTest(MockTest m) throws SQLException {
        String sql = "UPDATE mock_tests SET name=?, test_date=?, score=?, time_taken=?, "
                   + "weak_areas=?, remarks=? WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getName());
            ps.setDate  (2, m.getTestDate());
            ps.setInt   (3, m.getScore());
            ps.setInt   (4, m.getTimeTaken());
            ps.setString(5, m.getWeakAreas());
            ps.setString(6, m.getRemarks());
            ps.setInt   (7, m.getId());
            ps.setInt   (8, m.getUserId());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ────────────────────────────────────────────────
    public boolean deleteMockTest(int id, int userId) throws SQLException {
        String sql = "DELETE FROM mock_tests WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Analytics: average score ─────────────────────────────
    public double getAverageScore(int userId) throws SQLException {
        String sql = "SELECT AVG(score) FROM mock_tests WHERE user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0.0;
            }
        }
    }

    // ── Analytics: best score ────────────────────────────────
    public int getBestScore(int userId) throws SQLException {
        String sql = "SELECT MAX(score) FROM mock_tests WHERE user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ── Mapper ───────────────────────────────────────────────
    private MockTest map(ResultSet rs) throws SQLException {
        MockTest m = new MockTest();
        m.setId        (rs.getInt      ("id"));
        m.setUserId    (rs.getInt      ("user_id"));
        m.setName      (rs.getString   ("name"));
        m.setTestDate  (rs.getDate     ("test_date"));
        m.setScore     (rs.getInt      ("score"));
        m.setTimeTaken (rs.getInt      ("time_taken"));
        m.setWeakAreas (rs.getString   ("weak_areas"));
        m.setRemarks   (rs.getString   ("remarks"));
        m.setCreatedAt (rs.getTimestamp("created_at"));
        return m;
    }
}
