package com.placementtracker.dao;

import com.placementtracker.model.User;
import com.placementtracker.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for the users table.
 * Supports basic lookup and creation — extend with password hashing for a real login flow.
 */
public class UserDAO {

    // ── Create ────────────────────────────────────────────────
    public boolean addUser(User u) throws SQLException {
        String sql = "INSERT INTO users (name, email, branch, grad_year) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getBranch());
            if (u.getGradYear() > 0) ps.setInt(4, u.getGradYear());
            else                     ps.setNull(4, Types.INTEGER);
            boolean ok = ps.executeUpdate() > 0;
            if (ok) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) u.setId(keys.getInt(1));
                }
            }
            return ok;
        }
    }

    // ── Read by id ────────────────────────────────────────────
    public User getUserById(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Read by email ─────────────────────────────────────────
    public User getUserByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Read all ──────────────────────────────────────────────
    public List<User> getAllUsers() throws SQLException {
        String sql = "SELECT * FROM users ORDER BY created_at DESC";
        List<User> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    // ── Update ────────────────────────────────────────────────
    public boolean updateUser(User u) throws SQLException {
        String sql = "UPDATE users SET name=?, branch=?, grad_year=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getBranch());
            if (u.getGradYear() > 0) ps.setInt(3, u.getGradYear());
            else                     ps.setNull(3, Types.INTEGER);
            ps.setInt(4, u.getId());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ────────────────────────────────────────────────
    public boolean deleteUser(int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Mapper ───────────────────────────────────────────────
    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId       (rs.getInt      ("id"));
        u.setName     (rs.getString   ("name"));
        u.setEmail    (rs.getString   ("email"));
        u.setBranch   (rs.getString   ("branch"));
        u.setGradYear (rs.getInt      ("grad_year"));
        u.setCreatedAt(rs.getTimestamp("created_at"));
        return u;
    }
}
