package com.placementtracker.dao;

import com.placementtracker.model.Topic;
import com.placementtracker.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data-Access Object for the topics table.
 * All SQL operations are parameterised to prevent SQL injection.
 */
public class TopicDAO {

    // ── Create ────────────────────────────────────────────────
    public boolean addTopic(Topic t) throws SQLException {
        String sql = "INSERT INTO topics (user_id, name, category, status, priority, progress, notes) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt   (1, t.getUserId());
            ps.setString(2, t.getName());
            ps.setString(3, t.getCategory());
            ps.setString(4, t.getStatus());
            ps.setString(5, t.getPriority());
            ps.setInt   (6, t.getProgress());
            ps.setString(7, t.getNotes());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Read all for user ────────────────────────────────────
    public List<Topic> getTopicsByUser(int userId) throws SQLException {
        String sql = "SELECT * FROM topics WHERE user_id = ? ORDER BY priority DESC, name";
        List<Topic> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Read single ──────────────────────────────────────────
    public Topic getTopicById(int id) throws SQLException {
        String sql = "SELECT * FROM topics WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    // ── Update ────────────────────────────────────────────────
    public boolean updateTopic(Topic t) throws SQLException {
        String sql = "UPDATE topics SET name=?, category=?, status=?, priority=?, progress=?, notes=? "
                   + "WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getName());
            ps.setString(2, t.getCategory());
            ps.setString(3, t.getStatus());
            ps.setString(4, t.getPriority());
            ps.setInt   (5, t.getProgress());
            ps.setString(6, t.getNotes());
            ps.setInt   (7, t.getId());
            ps.setInt   (8, t.getUserId());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ────────────────────────────────────────────────
    public boolean deleteTopic(int id, int userId) throws SQLException {
        String sql = "DELETE FROM topics WHERE id=? AND user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Analytics: count by status ───────────────────────────
    public int countByStatus(int userId, String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM topics WHERE user_id=? AND status=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt   (1, userId);
            ps.setString(2, status);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ── Analytics: low-progress topics (weak areas) ──────────
    public List<Topic> getWeakTopics(int userId, int threshold) throws SQLException {
        String sql = "SELECT * FROM topics WHERE user_id=? AND progress < ? AND status != 'Completed' "
                   + "ORDER BY priority DESC, progress ASC";
        List<Topic> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, threshold);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    // ── Mapper ───────────────────────────────────────────────
    private Topic map(ResultSet rs) throws SQLException {
        Topic t = new Topic();
        t.setId       (rs.getInt      ("id"));
        t.setUserId   (rs.getInt      ("user_id"));
        t.setName     (rs.getString   ("name"));
        t.setCategory (rs.getString   ("category"));
        t.setStatus   (rs.getString   ("status"));
        t.setPriority (rs.getString   ("priority"));
        t.setProgress (rs.getInt      ("progress"));
        t.setNotes    (rs.getString   ("notes"));
        t.setCreatedAt(rs.getTimestamp("created_at"));
        t.setUpdatedAt(rs.getTimestamp("updated_at"));
        return t;
    }
}
