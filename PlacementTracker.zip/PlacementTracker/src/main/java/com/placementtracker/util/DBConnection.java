package com.placementtracker.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Provides a JDBC connection to the placement_tracker MySQL database.
 * Update DB_URL / USER / PASSWORD to match your environment.
 */
public class DBConnection {

    private static final String DB_URL  = "jdbc:mysql://localhost:3306/placement_tracker"
                                         + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER     = "root";
    private static final String PASSWORD = "root";          // change me

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found", e);
        }
    }

    /** Returns a new connection; caller is responsible for closing it. */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASSWORD);
    }

    private DBConnection() {}   // utility class — no instances
}
