package com.placementtracker.util;

import javax.servlet.*;
import java.io.IOException;

/** Forces UTF-8 request/response encoding on every request. */
public class EncodingFilter implements Filter {

    private String encoding = "UTF-8";

    @Override
    public void init(FilterConfig cfg) {
        String enc = cfg.getInitParameter("encoding");
        if (enc != null && !enc.isEmpty()) this.encoding = enc;
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        req.setCharacterEncoding(encoding);
        res.setCharacterEncoding(encoding);
        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {}
}
