package com.placementtracker.model;

import java.sql.Timestamp;

public class Topic {
    private int id;
    private int userId;
    private String name;
    private String category;
    private String status;
    private String priority;
    private int progress;
    private String notes;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public Topic() {}

    public Topic(int userId, String name, String category,
                 String status, String priority, int progress, String notes) {
        this.userId   = userId;
        this.name     = name;
        this.category = category;
        this.status   = status;
        this.priority = priority;
        this.progress = progress;
        this.notes    = notes;
    }

    // ── Getters & Setters ─────────────────────────────────────
    public int       getId()        { return id; }
    public void      setId(int id)  { this.id = id; }

    public int       getUserId()           { return userId; }
    public void      setUserId(int userId) { this.userId = userId; }

    public String    getName()           { return name; }
    public void      setName(String n)   { this.name = n; }

    public String    getCategory()              { return category; }
    public void      setCategory(String c)      { this.category = c; }

    public String    getStatus()              { return status; }
    public void      setStatus(String s)      { this.status = s; }

    public String    getPriority()               { return priority; }
    public void      setPriority(String p)       { this.priority = p; }

    public int       getProgress()              { return progress; }
    public void      setProgress(int p)         { this.progress = p; }

    public String    getNotes()           { return notes; }
    public void      setNotes(String n)   { this.notes = n; }

    public Timestamp getCreatedAt()                   { return createdAt; }
    public void      setCreatedAt(Timestamp t)        { this.createdAt = t; }

    public Timestamp getUpdatedAt()                   { return updatedAt; }
    public void      setUpdatedAt(Timestamp t)        { this.updatedAt = t; }

    @Override
    public String toString() {
        return "Topic{id=" + id + ", name='" + name + "', status='" + status
               + "', progress=" + progress + "%}";
    }
}
