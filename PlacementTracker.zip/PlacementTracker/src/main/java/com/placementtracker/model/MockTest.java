package com.placementtracker.model;

import java.sql.Date;
import java.sql.Timestamp;

public class MockTest {
    private int id;
    private int userId;
    private String name;
    private Date testDate;
    private int score;          // 0-100 %
    private int timeTaken;      // minutes
    private String weakAreas;
    private String remarks;
    private Timestamp createdAt;

    public MockTest() {}

    public MockTest(int userId, String name, Date testDate, int score,
                    int timeTaken, String weakAreas, String remarks) {
        this.userId    = userId;
        this.name      = name;
        this.testDate  = testDate;
        this.score     = score;
        this.timeTaken = timeTaken;
        this.weakAreas = weakAreas;
        this.remarks   = remarks;
    }

    // ── Getters & Setters ─────────────────────────────────────
    public int    getId()         { return id; }
    public void   setId(int id)   { this.id = id; }

    public int    getUserId()            { return userId; }
    public void   setUserId(int u)       { this.userId = u; }

    public String getName()            { return name; }
    public void   setName(String n)    { this.name = n; }

    public Date   getTestDate()                { return testDate; }
    public void   setTestDate(Date d)          { this.testDate = d; }

    public int    getScore()           { return score; }
    public void   setScore(int s)      { this.score = s; }

    public int    getTimeTaken()              { return timeTaken; }
    public void   setTimeTaken(int t)         { this.timeTaken = t; }

    public String getWeakAreas()               { return weakAreas; }
    public void   setWeakAreas(String w)       { this.weakAreas = w; }

    public String getRemarks()               { return remarks; }
    public void   setRemarks(String r)       { this.remarks = r; }

    public Timestamp getCreatedAt()                   { return createdAt; }
    public void      setCreatedAt(Timestamp t)        { this.createdAt = t; }

    @Override
    public String toString() {
        return "MockTest{id=" + id + ", name='" + name + "', score=" + score + "%}";
    }
}
