package com.placementtracker.model;

import java.sql.Timestamp;

public class User {
    private int id;
    private String name;
    private String email;
    private String branch;
    private int gradYear;
    private Timestamp createdAt;

    public User() {}

    public User(String name, String email, String branch, int gradYear) {
        this.name     = name;
        this.email    = email;
        this.branch   = branch;
        this.gradYear = gradYear;
    }

    public int       getId()               { return id; }
    public void      setId(int id)         { this.id = id; }

    public String    getName()             { return name; }
    public void      setName(String n)     { this.name = n; }

    public String    getEmail()            { return email; }
    public void      setEmail(String e)    { this.email = e; }

    public String    getBranch()           { return branch; }
    public void      setBranch(String b)   { this.branch = b; }

    public int       getGradYear()         { return gradYear; }
    public void      setGradYear(int y)    { this.gradYear = y; }

    public Timestamp getCreatedAt()              { return createdAt; }
    public void      setCreatedAt(Timestamp t)   { this.createdAt = t; }

    @Override
    public String toString() {
        return "User{id=" + id + ", name='" + name + "', email='" + email + "'}";
    }
}
