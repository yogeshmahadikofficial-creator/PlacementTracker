package com.placementtracker.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Problem {
    private int id;
    private int userId;
    private String name;
    private String topic;
    private String difficulty;
    private String status;
    private int timeTaken;       // minutes
    private String notes;
    private Date solvedDate;
    private Timestamp createdAt;

    public Problem() {}

    public Problem(int userId, String name, String topic, String difficulty,
                   String status, int timeTaken, String notes, Date solvedDate) {
        this.userId     = userId;
        this.name       = name;
        this.topic      = topic;
        this.difficulty = difficulty;
        this.status     = status;
        this.timeTaken  = timeTaken;
        this.notes      = notes;
        this.solvedDate = solvedDate;
    }

    // ── Getters & Setters ─────────────────────────────────────
    public int    getId()         { return id; }
    public void   setId(int id)   { this.id = id; }

    public int    getUserId()            { return userId; }
    public void   setUserId(int u)       { this.userId = u; }

    public String getName()            { return name; }
    public void   setName(String n)    { this.name = n; }

    public String getTopic()             { return topic; }
    public void   setTopic(String t)     { this.topic = t; }

    public String getDifficulty()                { return difficulty; }
    public void   setDifficulty(String d)        { this.difficulty = d; }

    public String getStatus()              { return status; }
    public void   setStatus(String s)      { this.status = s; }

    public int    getTimeTaken()              { return timeTaken; }
    public void   setTimeTaken(int t)         { this.timeTaken = t; }

    public String getNotes()            { return notes; }
    public void   setNotes(String n)    { this.notes = n; }

    public Date   getSolvedDate()                { return solvedDate; }
    public void   setSolvedDate(Date d)          { this.solvedDate = d; }

    public Timestamp getCreatedAt()                   { return createdAt; }
    public void      setCreatedAt(Timestamp t)        { this.createdAt = t; }

    @Override
    public String toString() {
        return "Problem{id=" + id + ", name='" + name + "', difficulty='"
               + difficulty + "', status='" + status + "'}";
    }
}
