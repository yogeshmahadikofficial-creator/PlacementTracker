/* ============================================================
   PlacePrep — app.js  (full client-side logic)
   ============================================================ */

const API = {
  dashboard : 'dashboard',
  topics    : 'topics',
  problems  : 'problems',
  mocks     : 'mocktests',
};

// ── Utilities ─────────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  const res = await fetch(url, opts);
  return res.json();
}

function formData(obj) {
  const fd = new URLSearchParams();
  Object.entries(obj).forEach(([k, v]) => { if (v !== null && v !== undefined) fd.append(k, v); });
  return fd;
}

function badge(type, text) {
  const map = {
    'Completed':'green','Solved':'green','Easy':'green',
    'In progress':'blue','Attempted':'amber','Medium':'amber',
    'Not started':'gray','Revisit':'red','Hard':'red',
    'High':'red','Low':'gray'
  };
  const cls = map[text] || 'gray';
  return `<span class="badge badge-${cls}">${text}</span>`;
}

function progressBar(pct, cls = '') {
  return `<div class="progress-wrap">
    <div class="progress-bar"><div class="progress-fill ${cls}" style="width:${pct}%"></div></div>
    <span class="progress-pct">${pct}%</span>
  </div>`;
}

function showAlert(id, msg, type = 'success') {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg;
  el.className = `alert alert-${type} show`;
  setTimeout(() => el.classList.remove('show'), 3000);
}

// ── Navigation ────────────────────────────────────────────────
function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  const el = document.getElementById('page-' + page);
  if (el) el.style.display = 'block';
  const link = document.querySelector(`nav a[data-page="${page}"]`);
  if (link) link.classList.add('active');
  if (page === 'dashboard') loadDashboard();
  if (page === 'topics')    loadTopics();
  if (page === 'problems')  loadProblems();
  if (page === 'mocks')     loadMocks();
  if (page === 'progress')  loadProgress();
}

// ── Dashboard ─────────────────────────────────────────────────
async function loadDashboard() {
  const data = await apiFetch(API.dashboard);
  const ts = data.topicStats || {};
  const ps = data.problemStats || {};
  const ms = data.mockStats || {};

  setText('dash-topics',   `${ts.completed || 0}/${ts.total || 0}`);
  setText('dash-solved',   ps.solved || 0);
  setText('dash-mocks',    ms.total  || 0);
  setText('dash-avg',      ms.avgScore ? ms.avgScore + '%' : '—');

  // Topic progress list
  const tl = document.getElementById('dash-topic-list');
  if (ts.list && ts.list.length) {
    tl.innerHTML = ts.list.slice(0, 6).map(t => `
      <div class="topic-row" style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span style="font-size:12px;font-weight:500">${t.name}</span>
          <span style="font-size:11px;color:var(--text-muted)">${t.category}</span>
        </div>
        ${progressBar(t.progress)}
      </div>`).join('');
  } else {
    tl.innerHTML = '<div class="empty-state">Add topics to see progress</div>';
  }

  // Recent problems
  const rp = document.getElementById('dash-recent');
  if (data.recentProblems && data.recentProblems.length) {
    rp.innerHTML = `<table><thead><tr>
      <th>Problem</th><th>Difficulty</th><th>Status</th><th>Date</th>
    </tr></thead><tbody>
      ${data.recentProblems.map(p => `<tr>
        <td class="td-name">${p.name}</td>
        <td>${badge('', p.difficulty)}</td>
        <td>${badge('', p.status)}</td>
        <td style="color:var(--text-muted);font-size:12px">${p.solvedDate || ''}</td>
      </tr>`).join('')}
    </tbody></table>`;
  } else {
    rp.innerHTML = '<div class="empty-state">No problems logged yet</div>';
  }

  buildHeatmap();
}

// ── Topics ────────────────────────────────────────────────────
async function loadTopics() {
  const topics = await apiFetch(API.topics);
  const tbody  = document.getElementById('topics-tbody');
  if (!topics.length) { tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No topics yet</td></tr>'; return; }
  tbody.innerHTML = topics.map(t => `<tr>
    <td><div class="td-name">${t.name}</div><div class="td-sub">${t.notes ? t.notes.slice(0,60) + (t.notes.length>60?'…':'') : ''}</div></td>
    <td><span class="badge badge-blue">${t.category}</span></td>
    <td>${badge('', t.status)}</td>
    <td style="min-width:130px">${progressBar(t.progress)}</td>
    <td>${badge('', t.priority)}</td>
    <td>
      <button class="btn btn-sm" onclick="openEditTopic(${t.id})">Edit</button>
      <button class="btn btn-sm btn-danger" onclick="deleteTopic(${t.id})">Delete</button>
    </td>
  </tr>`).join('');
}

function openAddTopic()       { document.getElementById('modal-topic').classList.add('open'); clearTopicForm(); }
function closeTopicModal()    { document.getElementById('modal-topic').classList.remove('open'); }

function clearTopicForm() {
  ['t-id','t-name','t-notes'].forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('t-progress').value = 0;
  document.getElementById('t-prog-val').textContent = '0%';
  document.getElementById('t-status').value   = 'Not started';
  document.getElementById('t-priority').value = 'Medium';
  document.getElementById('t-category').value = 'DSA';
  document.getElementById('modal-topic-title').textContent = 'Add topic';
}

async function openEditTopic(id) {
  const t = await apiFetch(API.topics + '?id=' + id);
  if (!t.id) return;
  document.getElementById('t-id').value       = t.id;
  document.getElementById('t-name').value     = t.name;
  document.getElementById('t-category').value = t.category;
  document.getElementById('t-status').value   = t.status;
  document.getElementById('t-priority').value = t.priority;
  document.getElementById('t-progress').value = t.progress;
  document.getElementById('t-prog-val').textContent = t.progress + '%';
  document.getElementById('t-notes').value    = t.notes || '';
  document.getElementById('modal-topic-title').textContent = 'Edit topic';
  document.getElementById('modal-topic').classList.add('open');
}

async function saveTopic() {
  const id       = document.getElementById('t-id').value;
  const name     = document.getElementById('t-name').value.trim();
  if (!name) { showAlert('topic-alert', 'Topic name is required', 'error'); return; }

  const payload = {
    name, category: document.getElementById('t-category').value,
    status: document.getElementById('t-status').value,
    priority: document.getElementById('t-priority').value,
    progress: document.getElementById('t-progress').value,
    notes: document.getElementById('t-notes').value,
  };

  let result;
  if (id) {
    payload.id = id;
    result = await apiFetch(API.topics + '?id=' + id, { method:'PUT', body: formData(payload) });
  } else {
    result = await apiFetch(API.topics, { method:'POST', body: formData(payload) });
  }

  if (result.success) {
    closeTopicModal();
    loadTopics();
    showAlert('topic-alert', result.message);
  } else {
    showAlert('topic-alert', result.message, 'error');
  }
}

async function deleteTopic(id) {
  if (!confirm('Delete this topic?')) return;
  const res = await apiFetch(API.topics + '?id=' + id, { method:'DELETE' });
  if (res.success) { loadTopics(); showAlert('topic-alert', 'Topic deleted'); }
}

// ── Problems ──────────────────────────────────────────────────
async function loadProblems() {
  const diff   = document.getElementById('filter-diff')?.value   || '';
  const status = document.getElementById('filter-status')?.value || '';
  let url = API.problems;
  const params = [];
  if (diff)   params.push('difficulty=' + diff);
  if (status) params.push('status=' + status);
  if (params.length) url += '?' + params.join('&');

  const problems = await apiFetch(url);
  const tbody    = document.getElementById('problems-tbody');
  if (!problems.length) { tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No problems match</td></tr>'; return; }
  tbody.innerHTML = problems.map(p => `<tr>
    <td><div class="td-name">${p.name}</div><div class="td-sub">${p.topic || ''} ${p.timeTaken ? '· ' + p.timeTaken + ' min' : ''}</div></td>
    <td><span class="badge badge-blue">${p.topic || '—'}</span></td>
    <td>${badge('', p.difficulty)}</td>
    <td>${badge('', p.status)}</td>
    <td style="color:var(--text-muted);font-size:12px">${p.solvedDate || ''}</td>
    <td>
      <button class="btn btn-sm" onclick="openEditProblem(${p.id})">Edit</button>
      <button class="btn btn-sm btn-danger" onclick="deleteProblem(${p.id})">Delete</button>
    </td>
  </tr>`).join('');
}

function openAddProblem()    { document.getElementById('modal-problem').classList.add('open'); clearProblemForm(); }
function closeProblemModal() { document.getElementById('modal-problem').classList.remove('open'); }

function clearProblemForm() {
  ['p-id','p-name','p-topic','p-time','p-notes'].forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('p-difficulty').value = 'Medium';
  document.getElementById('p-status').value     = 'Solved';
  document.getElementById('p-date').value       = new Date().toISOString().split('T')[0];
  document.getElementById('modal-problem-title').textContent = 'Log problem';
}

async function openEditProblem(id) {
  const p = await apiFetch(API.problems + '?id=' + id);
  if (!p.id) return;
  document.getElementById('p-id').value         = p.id;
  document.getElementById('p-name').value       = p.name;
  document.getElementById('p-topic').value      = p.topic || '';
  document.getElementById('p-difficulty').value = p.difficulty;
  document.getElementById('p-status').value     = p.status;
  document.getElementById('p-time').value       = p.timeTaken || '';
  document.getElementById('p-notes').value      = p.notes || '';
  document.getElementById('p-date').value       = p.solvedDate || '';
  document.getElementById('modal-problem-title').textContent = 'Edit problem';
  document.getElementById('modal-problem').classList.add('open');
}

async function saveProblem() {
  const id   = document.getElementById('p-id').value;
  const name = document.getElementById('p-name').value.trim();
  if (!name) { showAlert('problem-alert', 'Problem name is required', 'error'); return; }

  const payload = {
    name, topic: document.getElementById('p-topic').value,
    difficulty: document.getElementById('p-difficulty').value,
    status: document.getElementById('p-status').value,
    timeTaken: document.getElementById('p-time').value,
    notes: document.getElementById('p-notes').value,
    solvedDate: document.getElementById('p-date').value,
  };

  let result;
  if (id) {
    result = await apiFetch(API.problems + '?id=' + id, { method:'PUT', body: formData(payload) });
  } else {
    result = await apiFetch(API.problems, { method:'POST', body: formData(payload) });
  }

  if (result.success) { closeProblemModal(); loadProblems(); showAlert('problem-alert', result.message); }
  else                { showAlert('problem-alert', result.message, 'error'); }
}

async function deleteProblem(id) {
  if (!confirm('Delete this problem?')) return;
  const res = await apiFetch(API.problems + '?id=' + id, { method:'DELETE' });
  if (res.success) { loadProblems(); showAlert('problem-alert', 'Problem deleted'); }
}

// ── Mock Tests ────────────────────────────────────────────────
async function loadMocks() {
  const mocks = await apiFetch(API.mocks);
  const tbody = document.getElementById('mocks-tbody');
  if (!mocks.length) { tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No mock tests recorded yet</td></tr>'; return; }
  tbody.innerHTML = mocks.map(m => {
    const scoreColor = m.score >= 75 ? 'var(--success)' : m.score >= 50 ? 'var(--warning)' : 'var(--danger)';
    return `<tr>
      <td class="td-name">${m.name}</td>
      <td style="font-size:12px;color:var(--text-muted)">${m.testDate || '—'}</td>
      <td><span style="font-size:16px;font-weight:600;color:${scoreColor}">${m.score}%</span></td>
      <td style="font-size:12px">${m.timeTaken ? m.timeTaken + ' min' : '—'}</td>
      <td style="font-size:12px;color:var(--text-muted)">${m.weakAreas || '—'}</td>
      <td>
        <button class="btn btn-sm" onclick="openEditMock(${m.id})">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteMock(${m.id})">Delete</button>
      </td>
    </tr>`;
  }).join('');
}

function openAddMock()    { document.getElementById('modal-mock').classList.add('open'); clearMockForm(); }
function closeMockModal() { document.getElementById('modal-mock').classList.remove('open'); }

function clearMockForm() {
  ['mk-id','mk-name','mk-score','mk-time','mk-weak','mk-remarks'].forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('mk-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('modal-mock-title').textContent = 'Record mock test';
}

async function openEditMock(id) {
  const m = await apiFetch(API.mocks + '?id=' + id);
  if (!m.id) return;
  document.getElementById('mk-id').value      = m.id;
  document.getElementById('mk-name').value    = m.name;
  document.getElementById('mk-date').value    = m.testDate || '';
  document.getElementById('mk-score').value   = m.score;
  document.getElementById('mk-time').value    = m.timeTaken || '';
  document.getElementById('mk-weak').value    = m.weakAreas || '';
  document.getElementById('mk-remarks').value = m.remarks || '';
  document.getElementById('modal-mock-title').textContent = 'Edit mock test';
  document.getElementById('modal-mock').classList.add('open');
}

async function saveMock() {
  const id   = document.getElementById('mk-id').value;
  const name = document.getElementById('mk-name').value.trim();
  if (!name) { showAlert('mock-alert', 'Test name is required', 'error'); return; }

  const payload = {
    name, testDate: document.getElementById('mk-date').value,
    score: document.getElementById('mk-score').value,
    timeTaken: document.getElementById('mk-time').value,
    weakAreas: document.getElementById('mk-weak').value,
    remarks: document.getElementById('mk-remarks').value,
  };

  let result;
  if (id) { result = await apiFetch(API.mocks + '?id=' + id, { method:'PUT', body: formData(payload) }); }
  else    { result = await apiFetch(API.mocks,               { method:'POST', body: formData(payload) }); }

  if (result.success) { closeMockModal(); loadMocks(); showAlert('mock-alert', result.message); }
  else                { showAlert('mock-alert', result.message, 'error'); }
}

async function deleteMock(id) {
  if (!confirm('Delete this test?')) return;
  const res = await apiFetch(API.mocks + '?id=' + id, { method:'DELETE' });
  if (res.success) { loadMocks(); showAlert('mock-alert', 'Test deleted'); }
}

// ── Progress page ─────────────────────────────────────────────
async function loadProgress() {
  const data = await apiFetch(API.dashboard);
  const ps   = data.problemStats || {};
  const ms   = data.mockStats    || {};
  const ts   = data.topicStats   || {};

  const easy = ps.easy || 0, medium = ps.medium || 0, hard = ps.hard || 0;
  const maxP = Math.max(easy, medium, hard, 1);
  setBarHeight('bar-easy',   easy,   maxP);
  setBarHeight('bar-medium', medium, maxP);
  setBarHeight('bar-hard',   hard,   maxP);
  setText('cnt-easy',   easy);
  setText('cnt-medium', medium);
  setText('cnt-hard',   hard);

  // Mock score chart
  const mocks = await apiFetch(API.mocks);
  const mc = document.getElementById('mock-bar-chart');
  if (mocks.length) {
    const maxS = Math.max(...mocks.map(m => m.score), 1);
    mc.innerHTML = mocks.slice(-8).map(m => {
      const col = m.score >= 75 ? '#1D9E75' : m.score >= 50 ? '#EF9F27' : '#E24B4A';
      return `<div class="bar-group" style="flex:1">
        <div class="bar" style="height:${Math.round(m.score/maxS*100)}px;background:${col};width:100%"></div>
        <div class="bar-label">${m.score}%</div>
      </div>`;
    }).join('');
  } else {
    mc.innerHTML = '<div class="empty-state" style="width:100%;font-size:12px">No mock tests yet</div>';
  }

  // Weak topics
  const wt = document.getElementById('weak-topics');
  if (ts.weak && ts.weak.length) {
    wt.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
      ${ts.weak.map(t => `
        <div style="background:var(--bg);border-radius:8px;padding:12px">
          <div style="font-size:12px;font-weight:500;margin-bottom:2px">${t.name}</div>
          <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px">${t.category} · ${t.priority} priority</div>
          <div class="progress-bar"><div class="progress-fill danger" style="width:${t.progress}%"></div></div>
          <div style="font-size:10px;color:var(--danger);margin-top:3px">${t.progress}% complete</div>
        </div>`).join('')}
    </div>`;
  } else {
    wt.innerHTML = '<div class="empty-state">All topics on track 🎉</div>';
  }
}

function setBarHeight(id, val, max) {
  const el = document.getElementById(id);
  if (el) el.style.height = Math.round(val / max * 100) + 'px';
}

// ── Heatmap ───────────────────────────────────────────────────
function buildHeatmap() {
  const days = ['S','M','T','W','T','F','S'];
  const lblEl = document.getElementById('hmap-labels');
  if (lblEl) lblEl.innerHTML = days.map(d => `<div style="flex:1;text-align:center;font-size:10px;color:var(--text-muted)">${d}</div>`).join('');
  const grid = document.getElementById('hmap-grid');
  if (!grid) return;
  const cells = Array.from({length:35}, () => {
    const r = Math.random();
    return r < .35 ? 0 : r < .55 ? 1 : r < .75 ? 2 : r < .9 ? 3 : 4;
  });
  grid.innerHTML = cells.map(c => `<div class="hmap-cell hmap-${c}"></div>`).join('');
}

// ── Helpers ───────────────────────────────────────────────────
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }

// Close modals on backdrop click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
});

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => navigate('dashboard'));
