-- ============================================================
--  PlacePrep - Placement Preparation Tracker
--  Database: placement_tracker
-- ============================================================

CREATE DATABASE IF NOT EXISTS placement_tracker
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE placement_tracker;

-- ── Users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  branch     VARCHAR(80),
  grad_year  YEAR,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Topics ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS topics (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  name       VARCHAR(150) NOT NULL,
  category   ENUM('DSA','Aptitude','System Design','OS','DBMS','OOP','Networking','Other') NOT NULL,
  status     ENUM('Not started','In progress','Completed') DEFAULT 'Not started',
  priority   ENUM('High','Medium','Low') DEFAULT 'Medium',
  progress   TINYINT UNSIGNED DEFAULT 0 CHECK (progress <= 100),
  notes      TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Problems ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS problems (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  name         VARCHAR(255) NOT NULL,
  topic        VARCHAR(100),
  difficulty   ENUM('Easy','Medium','Hard') DEFAULT 'Medium',
  status       ENUM('Solved','Attempted','Revisit') DEFAULT 'Attempted',
  time_taken   SMALLINT UNSIGNED COMMENT 'minutes',
  notes        TEXT,
  solved_date  DATE DEFAULT (CURDATE()),
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Mock Tests ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mock_tests (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  name        VARCHAR(200) NOT NULL,
  test_date   DATE,
  score       TINYINT UNSIGNED CHECK (score <= 100),
  time_taken  SMALLINT UNSIGNED COMMENT 'minutes',
  weak_areas  VARCHAR(500),
  remarks     TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Seed demo user ───────────────────────────────────────────
INSERT INTO users (name, email, branch, grad_year)
VALUES ('Demo Student', 'demo@placementtracker.com', 'B.Tech CSE', 2025);

-- ── Seed topics ──────────────────────────────────────────────
INSERT INTO topics (user_id, name, category, status, priority, progress, notes) VALUES
(1, 'Arrays & Strings',     'DSA',         'Completed',   'High',   100, 'Sliding window, two pointers, prefix sum'),
(1, 'Linked Lists',         'DSA',         'Completed',   'High',   100, 'Reversal, cycle detection, merge'),
(1, 'Trees & BST',          'DSA',         'In progress', 'High',   70,  'BFS, DFS, LCA — AVL pending'),
(1, 'Dynamic Programming',  'DSA',         'In progress', 'High',   45,  'Memoisation done; tabulation WIP'),
(1, 'Graphs',               'DSA',         'Not started', 'High',   15,  'Dijkstra, BFS/DFS, union-find'),
(1, 'Quantitative Aptitude','Aptitude',    'In progress', 'Medium', 60,  'Percentage, profit/loss, time-work done'),
(1, 'Logical Reasoning',    'Aptitude',    'In progress', 'Medium', 50,  'Syllogisms, blood relations'),
(1, 'OS Concepts',          'OS',          'Not started', 'Medium', 20,  'Scheduling, deadlock, memory mgmt'),
(1, 'DBMS & SQL',           'DBMS',        'In progress', 'High',   55,  'Normalisation, indexing, transactions'),
(1, 'OOP Principles',       'OOP',         'Completed',   'Medium', 90,  'SOLID, design patterns overview'),
(1, 'Computer Networks',    'Networking',  'Not started', 'Low',    10,  'OSI model, TCP/IP, HTTP'),
(1, 'System Design Basics', 'System Design','Not started','Medium', 0,   'Load balancing, caching, CAP theorem');

-- ── Seed problems ────────────────────────────────────────────
INSERT INTO problems (user_id, name, topic, difficulty, status, time_taken, notes, solved_date) VALUES
(1, 'Two Sum',                    'Arrays',           'Easy',   'Solved',    15, 'HashMap O(n)',                    CURDATE()),
(1, 'Best Time to Buy Stock',     'Arrays',           'Easy',   'Solved',    20, 'Single pass min tracking',        CURDATE()),
(1, 'Longest Substring No Repeat','Strings',          'Medium', 'Solved',    35, 'Sliding window + set',            CURDATE()),
(1, 'Merge Two Sorted Lists',     'Linked Lists',     'Easy',   'Solved',    20, 'Iterative merge',                 CURDATE()),
(1, 'Binary Tree Level Order',    'Trees',            'Medium', 'Solved',    40, 'BFS with queue',                  CURDATE()),
(1, 'Climbing Stairs',            'Dynamic Programming','Easy', 'Solved',    15, 'Classic DP / Fibonacci',          CURDATE()),
(1, 'Coin Change',                'Dynamic Programming','Medium','Attempted', 55, 'Bottom-up DP — TLE on edge case', CURDATE()),
(1, 'Number of Islands',          'Graphs',           'Medium', 'Revisit',   50, 'DFS flood fill — revisit union find',CURDATE()),
(1, 'Valid Parentheses',          'Strings',          'Easy',   'Solved',    12, 'Stack',                           CURDATE()),
(1, 'LRU Cache',                  'DBMS',             'Hard',   'Attempted', 75, 'LinkedHashMap approach noted',    CURDATE());

-- ── Seed mock tests ──────────────────────────────────────────
INSERT INTO mock_tests (user_id, name, test_date, score, time_taken, weak_areas, remarks) VALUES
(1, 'TCS NQT Mock 1',      DATE_SUB(CURDATE(), INTERVAL 20 DAY), 62, 90, 'Probability, Series completion', 'Rushed the last section'),
(1, 'Infosys SP Mock',     DATE_SUB(CURDATE(), INTERVAL 14 DAY), 71, 80, 'Coding: DP problems',            'Aptitude improved significantly'),
(1, 'Wipro NLTH Mock',     DATE_SUB(CURDATE(), INTERVAL 7  DAY), 78, 85, 'Verbal ability',                 'Best score so far'),
(1, 'Full Mock — Combined',DATE_SUB(CURDATE(), INTERVAL 2  DAY), 81, 120,'Graphs, System Design',          'Need to revise graphs before finals');
